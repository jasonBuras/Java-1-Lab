//Jason Buras Problem 4: SimpleAddition
//import section
import java.util.Scanner;

public class SimpleAddition{
	public static void main(String[] args) {
		Scanner obj= new Scanner(System.in);
		int first= obj.nextInt();
		int second= obj.nextInt();
		System.out.println(first+second);
	}
}