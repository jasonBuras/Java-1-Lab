//Jason Buras Problem 4: Bouncer Bot
import java.util.Scanner;
public class BouncerBot{
	public static void main(String[] args)
	{
		Scanner obj= new Scanner(System.in);
		int currentMonth=obj.nextInt();
		int currentDay= obj.nextInt();
		int currentYear= obj.nextInt();
		int birthMonth= obj.nextInt();
		int birthDay= obj.nextInt();
		int birthYear= obj.nextInt();

		boolean enter= currentYear - birthYear >= 21 && currentMonth == birthMonth && currentDay == birthDay;
		System.out.printf("%b\n",enter);
			}
}