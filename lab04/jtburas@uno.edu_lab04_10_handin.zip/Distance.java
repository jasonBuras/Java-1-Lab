//Jason Buras Problem 7: Distance
import java.util.Scanner;

public class Distance{
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		int cases=obj.nextInt();
		obj.nextLine();

		for (int i=0;i<cases;i++){
			double x1 = obj.nextDouble();
			double y1 = obj.nextDouble();

			double x2 = obj.nextDouble();
			double y2 = obj.nextDouble();

			double distance = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
			System.out.println(distance);
		}
	}
}


