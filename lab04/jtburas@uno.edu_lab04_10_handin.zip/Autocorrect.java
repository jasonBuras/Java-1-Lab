//Jason Buras Problem 5: Autocorrect
/* Input:					Output:
 * Helo Wolrd				Hello World
 * Helo Hello Wolrd World
 *
 * yuDodat?					WhyYouDoThat?
 * y Why u You dat That 	
 * 
 * h3110 70 411				hello to all
 * 3 e 1 l 0 o 4 a 7 t	
 */
import java.util.Scanner;
public class Autocorrect{
	public static void main(String[] args){
		Scanner obj = new Scanner(System.in);
		int cases = obj.nextInt();
		obj.nextLine();

		for (int i=0;i<cases;i++){
			String autoCorrect = "";
			String input = obj.nextLine();
			String dict = obj.nextLine();
			Scanner reader = new Scanner(dict);
			while (reader.hasNext()){
				String key = reader.next();
				String value = reader.next();
				input = input.replace(key, value);
			}
			System.out.println(input);
		}
	}
}
