//Jason Buras Problem 6: String Util
public class StringUtil{
	public static String toString(double data){
		//returns data as a String
		return Double.toString(data);
	}
	public static String toString(float data){
		//returns data as a String
		return Float.toString(data);
	}
	public static String toString(int data){
		//returns data as a String
		return Integer.toString(data);
	}
	public static String toString(long data){
		//returns data as a String
		return Long.toString(data);
	}
	public static String toString(char data){
		//returns data as a String
		return Character.toString(data);
	}
	public static String toString(boolean data){
		//returns data as a String
		return Boolean.toString(data);
	}
}