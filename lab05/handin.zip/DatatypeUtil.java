//Jason Buras Problem 1: Datatype Util
public class DatatypeUtil{
	public static String getType(double data){
		return "double";
	}
	public static String getType(float data){
		return "float";
	}
	public static String getType(int data){
		return "int";
	}
	public static String getType(long data){
		return "long";
	}
	public static String getType(char data){
		return "char";
	}
	public static String getType(boolean data){
		return "boolean";
	}
	public static String getType(String data){
		return "String";
	}
}